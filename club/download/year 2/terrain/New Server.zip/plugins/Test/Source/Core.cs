using Server.Plugins;
using Server.Worlds;
using Shared.Mathf;
using Shared.Worlds;
public class Core : Plugin
{
    public override void OnRegister()
    {
        // Register our custom blocks :D
        Blocks.Register();
        Items.Register();
    }
    public override void OnLoad()
    {
        // Setup the terrain generator
        Multiverse.GetMainWorld().SetWorldGenerator(new MyWorldGenerator());

        Multiverse.OnPlayerJoin += OnPlayerJoin;

        Multiverse.GetMainWorld().FillText(Blocks.Stone, new Shared.Mathf.Vector3(-70, 30, 0), "Lets Go Code!", Vector3.Right, Vector3.Up, -1);
    }

    private void OnPlayerJoin(PlayerEntity player)
    {
        // Give the default items to the player
        player.Inventory.AddItem(new ItemStack(Items.Block, 1));
        player.Inventory.AddItem(new ItemStack(Items.Pickaxe, 1));
    }
}