﻿using Shared.Worlds;

public class MyWorldGenerator : WorldGenerator
{
    public override Block Generate(int x, int y, int z)
    {
        // If we are filling in the block below y = 0, set it to stone
        if (y < MathF.Abs(x * 0.3f) + MathF.Abs(z * 0.3f))
        {
            return Blocks.Grass;
        }

        return Blocks.Air;
    }
}
