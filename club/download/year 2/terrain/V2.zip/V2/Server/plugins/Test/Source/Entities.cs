﻿using Shared.Worlds;
namespace PluginCode;

public class Entities
{
    public static EntityType Player = Registry.GetEntity("player")!;
    public static EntityType Sheep = EntityType.Unregisterd;

    public static void Register()
    {
        Sheep = Registry.CreateEntity("sheep");
        Sheep.Mesh = "Monkey";
    }
}
