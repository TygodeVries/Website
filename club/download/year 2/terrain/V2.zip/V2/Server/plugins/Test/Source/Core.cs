using Server.Plugins;
using Server.Worlds;
using Shared.Worlds;
namespace PluginCode;

public class Core : Plugin
{


    public static Item pickaxeItem = Item.Unregistered;
    public static Item blockItem = Item.Unregistered;
    public override void OnRegister()
    {
        Blocks.Register();
        Entities.Register();

        blockItem = Registry.CreateItem("block");
        blockItem.texture = "block";

        blockItem.OnBlockRightClick += (args) =>
        {
            Sheep sheep = new Sheep();
            args.GetWorld().SpawnEntity(sheep);
            sheep.Teleport(args.Block + args.Normal + new Shared.Mathf.Vector3(0, 3, 0));
        };

        pickaxeItem = Registry.CreateItem("pickaxe");
        pickaxeItem.texture = "pickaxe";

        pickaxeItem.OnBlockLeftClick += ItemBehaviour.BreakBlock();

        Console.WriteLine("Regiserty...");
    }
    public override void OnLoad()
    {
        Console.WriteLine("Plugin Loading...");
        Multiverse.GetMainWorld().SetWorldGenerator(new ExampleTerrainGenerator());

        Multiverse.OnPlayerJoin += OnPlayerJoin;
    }

    private void OnPlayerJoin(PlayerEntity player)
    {
        Console.WriteLine("Player Joined!");
        player.SendToast("<red>Welcome <yellow>to <white>my server!");
        player.Inventory.AddItem(new ItemStack(blockItem));
    }
}