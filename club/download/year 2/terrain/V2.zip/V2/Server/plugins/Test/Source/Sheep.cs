﻿using Server.Worlds;
using Shared.Worlds;

namespace PluginCode;

internal class Sheep : Creature
{
    public override void SetGoals()
    {
        AddGoal(new ConsumeBlockGoal(Blocks.Grass, 2, 100));
        AddGoal(new FollowBlockGoal(Blocks.Grass, 10, 50));

        AddGoal(new RandomWanderGoal(10));
    }

    public override EntityType GetEntityType()
    {
        return Entities.Sheep;
    }
}
