﻿using Shared.Mathf;
using Shared.Worlds;
namespace PluginCode;

public class ExampleTerrainGenerator : WorldGenerator
{
    public override Block Generate(int x, int y, int z)
    {
        float distance = new Vector3(x, y, z).Length;

        if (distance < 20 && y == -1)
        {
            return Blocks.Grass;
        }

        if (distance < 20 && y < -1)
        {
            return Blocks.Stone;
        }

        return DefaultBlocks.AIR;
    }



}
