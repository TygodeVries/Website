﻿using Shared.Worlds;
namespace PluginCode;

public class Blocks
{
    public static Block Grass = Block.Unregistered;
    public static Block Stone = Block.Unregistered;
    public static void Register()
    {
        // Create Grass block
        Grass = Registry.CreateBlock("grass");
        Grass.Texture = new BlockTexture()
            .Fill("grass_side")
            .SetFace(BlockFace.Up, "grass_top")
            .SetFace(BlockFace.Down, "grass_bottom");

        // Create stone block
        Stone = Registry.CreateBlock("stone");
        Stone.Texture = new BlockTexture()
            .Fill("stone");
    }
}
