#version 330 core

in float Distance;
in vec2 Uv;
in vec3 Color;

out vec4 FragColor;

uniform sampler2D u_Color;

void main()
{   
    vec4 texColor = texture(u_Color, Uv);
    if(texColor.a < 0.1)
    {
        FragColor = vec4(0, 0, 0, 0.3);
        return;
    }

    FragColor = texColor * vec4(Color, 1);
}