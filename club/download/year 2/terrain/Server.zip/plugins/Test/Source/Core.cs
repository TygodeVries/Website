
using Server.Plugins;
using Server.Worlds;
using Shared.Worlds;
public class Core : Plugin
{
    public override void OnRegister()
    {
        // Register our custom blocks :D
        Blocks.Register();
        Items.Register();
    }
    public override void OnLoad()
    {
        // Setup the terrain generator
        Multiverse.GetMainWorld().SetWorldGenerator(new MyWorldGenerator());

        Multiverse.OnPlayerJoin += OnPlayerJoin;
    }

    private void OnPlayerJoin(PlayerEntity player)
    {
        // Give the default items to the player
        player.Inventory.AddItem(new ItemStack(Items.Block, 1));
        player.Inventory.AddItem(new ItemStack(Items.Pickaxe, 1));
    }
}