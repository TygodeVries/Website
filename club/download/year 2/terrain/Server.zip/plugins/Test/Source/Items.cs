﻿using Shared.Worlds;

public class Items
{
    public static Item Pickaxe = Item.Unregistered;
    public static Item Block = Item.Unregistered;

    public static void Register()
    {
        // Register the item that allows you to place blocks
        Block = Registry.CreateItem("block");
        Block.texture = "block";

        // When we right click with the item, we want to place stone
        Block.OnBlockRightClick += ItemBehaviour.PlaceBlock(Blocks.Stone);

        // Create an item that allows us to break block
        Pickaxe = Registry.CreateItem("pickaxe");
        Pickaxe.texture = "pickaxe";

        Pickaxe.OnBlockLeftClick += ItemBehaviour.BreakBlock();
    }
}
