#version 330 core

in vec2 Uv;

out vec4 FragColor;

uniform sampler2D u_Color;

void main()
{
    vec4 texColor = texture(u_Color, Uv);
    FragColor =texColor;
}