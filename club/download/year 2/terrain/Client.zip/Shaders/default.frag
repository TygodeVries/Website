#version 330 core

in float Distance;
in vec2 Uv;
in vec3 Normal;
in vec4 FragPosLightSpace;
in float AO;

out vec4 FragColor;

uniform sampler2D u_Color;
uniform sampler2D shadowMap;

uniform int u_Debug;

float CalculateShadow(vec4 fragPosLightSpace)
{
    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
    projCoords = projCoords * 0.5 + 0.5;

    // Outside the shadow map / behind the light
    if (projCoords.z > 1.0 ||
        projCoords.x < 0.0 || projCoords.x > 1.0 ||
        projCoords.y < 0.0 || projCoords.y > 1.0)
    {
        return 0.0;
    }

    float closestDepth = texture(shadowMap, projCoords.xy).r;
    float currentDepth = projCoords.z;

    vec3 norm = normalize(Normal);

    // IMPORTANT: this should match your actual lighting direction.
    vec3 sunDir = normalize(vec3(0.4, 1.0, 0.4));

    float bias = max(
        0.05 * (1.0 - dot(norm, sunDir)),
        0.005
    );

    return currentDepth - bias > closestDepth ? 1.0 : 0.0;
}

void main()
{
    vec4 texColor = texture(u_Color, Uv);

    vec3 norm = normalize(Normal);
    vec3 sunDir = normalize(vec3(0.4, 1.0, 0.4));

    // Lighting
    float light = dot(norm, sunDir);

    light = (light + 1.0) / 2.0;
    light = max(light, 0.4);

    // Shadow
    float shadow = CalculateShadow(FragPosLightSpace);

    float shadowModifier = max(1.0 - shadow, 0.4);

    // Fade shadows with distance
    float shadowFadeStart = 25.0;
    float shadowFadeEnd = 30.0;

    if (Distance > shadowFadeStart)
    {
        float fadeFactor =
            (Distance - shadowFadeStart) /
            (shadowFadeEnd - shadowFadeStart);

        fadeFactor = clamp(fadeFactor, 0.0, 1.0);

        shadowModifier = mix(
            shadowModifier,
            1.0,
            fadeFactor
        );
    }

    // Lighting + shadow
    vec4 color = texColor * light * shadowModifier;

    // Fog
    float fogStart = 200.0;
    float fogEnd = 800.0;

    float fogFactor =
        (Distance - fogStart) /
        (fogEnd - fogStart);

    fogFactor = clamp(fogFactor, 0.0, 1.0);

    vec3 fogColor = vec3(0.65, 0.72, 0.80);

    vec3 outColor = mix(
        color.rgb * AO,
        fogColor,
        fogFactor
    );

    FragColor = vec4(outColor, 1.0);

    // Debug: Ambient Occlusion
    if (u_Debug == 1)
    {
        FragColor = vec4(AO, AO, AO, 1.0);
    }

    // Debug: Normal
    if (u_Debug == 2)
    {
        FragColor = vec4(normalize(Normal) * 0.5 + 0.5, 1.0);
    }

    // Debug: UV
    if (u_Debug == 3)
    {
        FragColor = vec4(Uv, 0.0, 1.0);
    }

    // Debug: Lighting
    if (u_Debug == 4)
    {
        FragColor = vec4(light, light, light, 1.0);
    }

    // Debug: Texture
    if (u_Debug == 5)
    {
        FragColor = texColor;
    }

    // Debug: No AO
    if (u_Debug == 6)
    {
        outColor = mix(
            color.rgb,
            fogColor,
            fogFactor
        );

        FragColor = vec4(outColor, 1.0);
    }
}